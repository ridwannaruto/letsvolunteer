<?php

namespace Ridwan\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RidwanSiteBundle extends Bundle
{
}
