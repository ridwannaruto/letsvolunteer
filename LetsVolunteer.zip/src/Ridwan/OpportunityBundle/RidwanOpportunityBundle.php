<?php

namespace Ridwan\OpportunityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RidwanOpportunityBundle extends Bundle
{
}
