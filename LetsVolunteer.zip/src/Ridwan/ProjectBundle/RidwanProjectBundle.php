<?php

namespace Ridwan\ProjectBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RidwanProjectBundle extends Bundle
{
}
