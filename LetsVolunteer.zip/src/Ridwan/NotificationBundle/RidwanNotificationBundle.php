<?php

namespace Ridwan\NotificationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RidwanNotificationBundle extends Bundle
{
}
