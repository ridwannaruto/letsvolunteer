<?php

   //this will NOT work, the browser received the HTML tag before the script


   header( 'Location: web/app_dev.php/login' ) ;

?>
